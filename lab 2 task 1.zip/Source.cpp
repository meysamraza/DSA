#include "shape.h"

int main()
{
    shape* s1 = new circle(5);
    shape* s2 = new rectangle(4, 6);

    s1->display();
    s2->display();

    delete s1;
    delete s2;

    return 0;
}
