#include "shape.h"
shape::shape() {}

circle::circle(const int& r) :rad(r) {}

rectangle::rectangle(const int& l, const int& w) :len(l), wid(w) {}

int circle::area() { return (3.14 * rad * rad); }

int rectangle::area() { return len * wid; }

void circle::display()
{
	cout << "area of the circle is : " << area();
}

void rectangle::display()
{
	cout << "area of the rectangle is : " << area();
}