#pragma once
#include<iostream>
using namespace std;
class shape
{
public:
	shape();
	virtual int area() = 0;
	virtual void display() = 0;
	virtual ~shape() {};
};
class circle :public shape
{
	int rad;
public:
	circle(const int& r);
	int area();
	void display();
};
class rectangle :public shape
{
	int len;
	int wid;
public:
	rectangle(const int& l, const int& w);
	int area();
	void display();
};
