#pragma once
#include<iostream>
using namespace std;

template<class t>
class item
{
protected:
	t* arr;
	int size;
	int csize;
public:
	item(const int& s);
	item(const item<t>& a);
	~item();

	virtual void addatfirst(const t& a) = 0;
	virtual void addatlast(const t& a) = 0;
	virtual t delfromend() = 0;
	virtual t delfromstart() = 0;

};

template<class t>
item<t>::item(const int& s)
{
	size = s;
	csize = 0;
	arr = new t[size];
	cout << "enter values of array till size : " << size << endl;
	for (int i = 0; i < size; i++)
	{
		cin >> arr[i];
	}

}

template<class t>
item<t>::item(const item<t>& a) :arr(a.arr), size(a.size), csize(a.csize) {}

template<class t>
item<t>::~item()
{
	delete[]arr;
}



