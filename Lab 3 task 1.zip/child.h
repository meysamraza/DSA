#pragma once
#include"item.h"
template<class t>
class obj :public item<t>
{
public:
	  obj(const int& s);
	  void addatfirst(const t& a) ;
	  void addatlast(const t& a) ;
	  t delfromend() ;
	  t delfromstart() ;
	  void display();
};

template<class t>
obj<t>::obj(const int& s) : item<t>(s) 
{
}


template<class t>
void obj<t>::addatfirst(const t& a)
{
	item<t>::arr[0] = a;
}

template<class t>
void obj<t>::addatlast(const t& a)
{
	item<t>::arr[item<t>::size-1] = a;
}

template<class t>
t obj<t>::delfromend()
{
	return item<t>::arr[item<t>::size-1];
}

template<class t>
t obj<t>::delfromstart()
{
	return item<t>::arr[0];
}

template<class t>
void obj<t>::display()
{

	for (int i = 0; i < item<t>::size; i++)
	{
		cout << i << ". " << item<t>::arr[i] << endl;
	}
}