#include"child.h"
int main()
{
	obj<int> a(5);
	a.addatfirst(100);
	a.delfromstart();
	a.addatlast(9000);
	a.delfromend();
	cout << "after modification\n";
	a.display();
}