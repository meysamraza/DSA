#pragma once
#include"item.h"
template<class t>
class Mylist : public item<t>
{
public:
	Mylist(const int& s);
	Mylist(const Mylist<t>& a);
	bool empty();
	bool full();
	int size();
	bool add(const int& i, const t& a);
	bool search(const t& a);
	t last();
	void display();

	void addatfirst(const t& a);
	void addatlast(const t& a);
	t delfromend();
	t delfromstart();

};

template<class t>
Mylist<t>::Mylist(const int& s) :item<t>(s) {}

template<class t>
Mylist<t>::Mylist(const Mylist<t>& a)
{
	item<t>::arr = a.item<t>::arr;
	item<t>::size = a.item<t>::size;
	item<t>::csize = a.item<t>::csize;
}

template<class t>
bool Mylist<t>::empty()
{
	return item<t>::csize == 0;
}
template<class t>
bool Mylist<t>::full()
{
	return item<t>::csize == item<t>::size;
}
template<class t>
int Mylist<t>::size()
{
	return item<t>::size;
}
template<class t>
bool Mylist<t>::add(const int& i, const t& a)
{
	if (full())
	{
		cout << "cant add item\n";
		return false;
	}
	else
	{
		item<t>::arr[i] = a;
		item<t>::csize++;
	}
	return true;
}
template<class t>
bool Mylist<t>::search(const t& a)
{
	for (int i = 0; i < item<t>::csize; i++)
	
		if (item<t>::arr[i] == a)
	
	return true;
}
template<class t>
t Mylist<t>::last()
{
	return item<t>::arr[item<t>::size - 1];
}
template<class t>
void Mylist<t>::addatfirst(const t& a)
{
	item<t>::arr[0] = a;
}

template<class t>
void Mylist<t>::addatlast(const t& a)
{
	item<t>::arr[item<t>::size - 1] = a;
}

template<class t>
t Mylist<t>::delfromend()
{
	return item<t>::arr[item<t>::size - 1];
}

template<class t>
t Mylist<t>::delfromstart()
{
	return item<t>::arr[0];
}

template<class t>
void Mylist<t>::display()
{
	for (int i = 0; i < item<t>::size; i++)
	{
		cout << i << ". " << item<t>::arr[i] << endl;
	}
}

