#include"child.h"
#include"MyList.h"

int main()
{
    int size;
    cout << "Enter the size of MyList: ";
    cin >> size;

    Mylist<int> a(size); // Object named 'a'

    int choice, value, index;

    cout << "\nMenu:\n";
    cout << "1. Check if empty\n";
    cout << "2. Check if full\n";
    cout << "3. Add at first\n";
    cout << "4. Add at last\n";
    cout << "5. Delete from start\n";
    cout << "6. Delete from end\n";
    cout << "7. Search\n";
    cout << "8. Add at index\n";
    cout << "9. Get last element\n";
    cout << "10. Display list\n";
    cout << "Enter your choice (or 0 to exit): ";
    cin >> choice;

    if (choice == 1) {
        if (a.empty()) {
            cout << "List is empty" << endl;
        }
        else {
            cout << "List is not empty" << endl;
        }
    }
    else if (choice == 2) {
        if (a.full()) {
            cout << "List is full" << endl;
        }
        else {
            cout << "List is not full" << endl;
        }
    }
    else if (choice == 3) {
        cout << "Enter value to add at first: ";
        cin >> value;
        a.addatfirst(value);
    }
    else if (choice == 4) {
        cout << "Enter value to add at last: ";
        cin >> value;
        a.addatlast(value);
    }
    else if (choice == 5) {
        cout << "Deleted value from start: " << a.delfromstart() << endl;
    }
    else if (choice == 6) {
        cout << "Deleted value from end: " << a.delfromend() << endl;
    }
    else if (choice == 7) {
        cout << "Enter value to search: ";
        cin >> value;
        if (a.search(value)) {
            cout << "Value found" << endl;
        }
        else {
            cout << "Value not found" << endl;
        }
    }
    else if (choice == 8) {
        cout << "Enter index and value to add: ";
        cin >> index >> value;
        if (a.add(index, value)) {
            cout << "Value added successfully.\n";
        }
        else {
            cout << "Failed to add value.\n";
        }
    }
    else if (choice == 9) {
        cout << "Last element: " << a.last() << endl;
    }
    else if (choice == 10) {
        cout << "Displaying list:\n";
        a.display();
    }
    else if (choice == 0) {
        cout << "Exiting program...\n";
    }
    else {
        cout << "Invalid choice. Please try again.\n";
    }

    return 0; // Program ends after one operation
}