#include "Class.h"

fulltime::fulltime(const int& s) :sal(s) {}

parttime::parttime(const int& h, const float& r) : hours(h), rate(r) {}

int fulltime::calsal() { return sal; }

int parttime::calsal() { return rate * hours; }

void fulltime::display()
{
	cout << "salary of full time employee is : " << calsal() << endl;
}

void parttime::display()
{
	cout << "salary of part time employee is : " << calsal() << endl;
}
