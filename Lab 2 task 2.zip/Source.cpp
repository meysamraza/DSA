#include"class.h"
int main()
{
	employee* e1 = new fulltime(8000);
	employee* e2 = new parttime(6, 67.9);

	e1->display();
	e2->display();

	delete e1;
	delete e2;
}