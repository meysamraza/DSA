#pragma once
#include<iostream>
using namespace std;
class employee
{
public:
	employee() {};
	virtual int calsal() = 0;
	virtual void display() = 0;
	virtual ~employee() {};
};

class fulltime : public employee
{
	int sal;
public:
	fulltime(const int &s);
	int calsal();
	void display();
};

class parttime : public employee
{
	int hours;
	float rate;
public:
	parttime(const int& h, const float& r);
	int calsal();
	void display();
};

